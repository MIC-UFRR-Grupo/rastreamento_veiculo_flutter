import 'package:google_maps_flutter/google_maps_flutter.dart';

String userName = "";
String googleMapKey = "AIzaSyDAwmPNzTa0nTwuxmqkvwczZyVzGjlifho";
const CameraPosition initialCameraPosition = CameraPosition(
  target: LatLng(2.8333356,-60.6963642),
  zoom: 15,
);