import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class VehicleListPage extends StatefulWidget {
  const VehicleListPage({super.key});

  @override
  State<VehicleListPage> createState() => _VehicleListPageState();
}

class _VehicleListPageState extends State<VehicleListPage> {
  final DatabaseReference _dbRef = FirebaseDatabase.instance.ref().child('vehicles');
  List<Map<String, dynamic>> _vehicles = [];

  @override
  void initState() {
    super.initState();
    _fetchVehicles();
  }

  void _fetchVehicles() {
    _dbRef.onValue.listen((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data != null) {
        List<Map<String, dynamic>> tempVehicles = [];
        data.forEach((key, value) {
          tempVehicles.add({
            'id': key,
            'marca': value['marca'] ?? 'Desconhecido',
            'modelo': value['modelo'] ?? 'Desconhecido',
            'cor': value['cor'] ?? 'Desconhecido',
            'ano': value['ano'] ?? 'Desconhecido',
            'em_movimento': value['em_movimento'] ?? false,
            'latitude': value['latitude'],
            'longitude': value['longitude'],
          });
        });
        setState(() {
          _vehicles = tempVehicles;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lista de Veículos'),
      ),
      body: ListView.builder(
        itemCount: _vehicles.length,
        itemBuilder: (context, index) {
          final vehicle = _vehicles[index];
          return ListTile(
            title: Text('${vehicle['marca']} ${vehicle['modelo']}'),
            subtitle: Text('Cor: ${vehicle['cor']} | Ano: ${vehicle['ano']}'),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(vehicle['em_movimento'] ? 'Em Movimento' : 'Parado',
                    style: TextStyle(
                        color: vehicle['em_movimento'] ? Colors.red : Colors.green)),
                IconButton(
                  icon: const Icon(Icons.map),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => VehicleMapPage(
                          latitude: vehicle['latitude'],
                          longitude: vehicle['longitude'],
                          title: '${vehicle['marca']} ${vehicle['modelo']}',
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddVehiclePage()),
          );
        },
      ),
    );
  }
}

class VehicleMapPage extends StatelessWidget {
  final double latitude;
  final double longitude;
  final String title;

  const VehicleMapPage({super.key, required this.latitude, required this.longitude, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: LatLng(latitude, longitude),
          zoom: 15,
        ),
        markers: {
          Marker(
            markerId: MarkerId(title),
            position: LatLng(latitude, longitude),
            infoWindow: InfoWindow(title: title),
          ),
        },
      ),
    );
  }
}

class AddVehiclePage extends StatefulWidget {
  const AddVehiclePage({super.key});

  @override
  State<AddVehiclePage> createState() => _AddVehiclePageState();
}

class _AddVehiclePageState extends State<AddVehiclePage> {
  final DatabaseReference _dbRef = FirebaseDatabase.instance.ref().child('vehicles');
  final TextEditingController _modelController = TextEditingController();
  final TextEditingController _brandController = TextEditingController();
  final TextEditingController _colorController = TextEditingController();
  final TextEditingController _yearController = TextEditingController();

  void _saveVehicle() {
    String id = _dbRef.push().key ?? '';
    _dbRef.child(id).set({
      'modelo': _modelController.text,
      'marca': _brandController.text,
      'cor': _colorController.text,
      'ano': _yearController.text,
      'em_movimento': false,
    });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Adicionar Veículo')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _modelController,
              decoration: InputDecoration(labelText: 'Modelo'),
            ),
            TextField(
              controller: _brandController,
              decoration: InputDecoration(labelText: 'Marca'),
            ),
            TextField(
              controller: _colorController,
              decoration: InputDecoration(labelText: 'Cor'),
            ),
            TextField(
              controller: _yearController,
              decoration: InputDecoration(labelText: 'Ano'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveVehicle,
              child: Text('Salvar'),
            ),
          ],
        ),
      ),
    );
  }
}
