package dev.ericamila.vehicle_monitoring

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
